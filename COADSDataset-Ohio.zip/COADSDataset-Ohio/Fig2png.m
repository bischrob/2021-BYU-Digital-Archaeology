myDir = uigetdir; %gets directory
myFiles = dir(fullfile(myDir,'*.fig')); %gets all wav files in struct
for k = 1:length(myFiles)
    nm = fullfile(myDir, myFiles(k).name)
    tmp = openfig(nm);
    newnm = strrep(nm,'fig','png')
    saveas(tmp,newnm)
end